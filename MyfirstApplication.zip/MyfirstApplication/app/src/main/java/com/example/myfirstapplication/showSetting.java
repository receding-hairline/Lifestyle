package com.example.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class showSetting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_setting);
    }

    public void enterChooseLanguage(View view) {
        Intent intent = new Intent(this, chooseLanguage.class);
        startActivity(intent);
    }
}
