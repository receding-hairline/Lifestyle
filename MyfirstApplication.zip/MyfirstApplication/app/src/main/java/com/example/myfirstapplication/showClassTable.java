package com.example.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import android.os.Bundle;
import java.util.ArrayList;
import android.view.LayoutInflater;
import android.view.View;


public class showClassTable extends AppCompatActivity {
    private ViewPager show_class_pager;
    private ArrayList<View> aList;
    private ArrayList<String> sList;
    private MyPagerAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_class);

        show_class_pager = (ViewPager) findViewById(R.id.vpager_show_class);

        aList = new ArrayList<View>();
        LayoutInflater li = getLayoutInflater();
        aList.add(li.inflate(R.layout.class_monday,null,false));
        aList.add(li.inflate(R.layout.class_tuesday,null,false));
        aList.add(li.inflate(R.layout.class_wednesday,null,false));
        aList.add(li.inflate(R.layout.class_thursday,null,false));
        aList.add(li.inflate(R.layout.class_friday,null,false));

        sList = new ArrayList<String>();
        sList.add("周一");
        sList.add("周二");
        sList.add("周三");
        sList.add("周四");
        sList.add("周五");
        mAdapter = new MyPagerAdapter(aList, sList);
        show_class_pager.setAdapter(mAdapter);
    }
}
