package com.example.myfirstapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        //Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);

        //Capture the layout's TextView and set the string as its text
        TextView textView = findViewById(R.id.textView);
        textView.setText(message);
    }
    //点击设置图标
    public void enterSetingPage(View view) {
        Intent intent = new Intent(this, showSetting.class);
        startActivity(intent);
    }
    //点击发帖图标
    public void enterPostPage(View view) {
        Intent intent = new Intent(this, showEditPost.class);
        startActivity(intent);
    }
    //点击圈子图标
    public void enterAllPost(View view) {
        Intent intent = new Intent(this, showAllPost.class);
        startActivity(intent);
    }
    //点击课程表按钮
    public void enterClassTable(View view) {
        Intent intent = new Intent(this, showClassTable.class);
        startActivity(intent);
    }

    //退出登录
    public void log_out(View view) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("小提示：");
        dialog.setMessage("请问您确定要退出么？");
        dialog.setCancelable(true);
        dialog.setPositiveButton("是的", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(DisplayMessageActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        dialog.setNegativeButton("不小心点错了", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        dialog.show();
    }
}
