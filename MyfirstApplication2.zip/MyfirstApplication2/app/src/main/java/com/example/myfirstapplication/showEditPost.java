package com.example.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Time;
import java.util.Date;

public class showEditPost extends AppCompatActivity {
    private EditText content;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_edit_post);

        content = (EditText) findViewById(R.id.editText_Edit_Post);
        result = (TextView) findViewById(R.id.text_result);

        Button share = (Button) findViewById(R.id.button_sendPost);
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((content.getText().toString()) == null || (content.getText().toString()).length() == 0) {
                    Toast.makeText(showEditPost.this, "内容不能为空！！", Toast.LENGTH_SHORT).show();
                } else {
                    SimpleDateFormat formatter = new   SimpleDateFormat   ("yyyy年MM月dd日   HH:mm:ss");
                    Date curDate =  new Date(System.currentTimeMillis());
                    String str = formatter.format(curDate);
                    savePost(123, content.getText().toString(), str);
                }
            }
        });
    }

    public void savePost(int userId, String cc, String tt) {
        String allInfo = "http://192.168.50.220:8080/SevletTest/SavePost" + "?userId=" + userId + "&content=" + cc + "&time=" + tt;
        new MyAsynTask(result).execute(allInfo);
    }

    public static class MyAsynTask extends AsyncTask<String, Integer, String> {
        private TextView tv;

        public MyAsynTask(TextView v) {
            tv = v;
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected String doInBackground(String... params) {
            //Log.w("WangJ", "task doInBackground()");
            HttpURLConnection connection = null;
            StringBuilder response = new StringBuilder();
            try {
                URL url = new URL(params[0]); // 声明一个URL,注意如果用百度首页实验，请使用https开头，否则获取不到返回报文
                connection = (HttpURLConnection) url.openConnection(); // 打开该URL连接
                connection.setRequestMethod("GET"); // 设置请求方法，“POST或GET”，我们这里用GET，在说到POST的时候再用POST
                connection.setConnectTimeout(80000); // 设置连接建立的超时时间
                connection.setReadTimeout(80000); // 设置网络报文收发超时时间
                InputStream in = connection.getInputStream();  // 通过连接的输入流获取下发报文，然后就是Java的流处理
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response.toString();
        }

        //@Override
        //protected void onProcessUpdate(Integer... values) {
        //}

        @Override
        protected void onPostExecute(String s) {
            tv.setText(s);
        }

    }

}
